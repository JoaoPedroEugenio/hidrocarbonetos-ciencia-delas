# Hidrocarbonetos — Ciência Delas (versão mobile)

Arquivos: index.html, tolueno.html, alfa-terpineno.html e style.css.

Esta versão foi ajustada para celular primeiro: as colunas viram uma única coluna em telas pequenas, os botões ficam fáceis de tocar, títulos e textos se adaptam ao tamanho da tela, as moléculas são SVG responsivo e o layout evita rolagem horizontal.

Também revisei o texto para ficar mais natural e com cara de trabalho de aluno, sem perder o conteúdo científico.

## GitHub Pages
Envie os quatro arquivos do site para a raiz do repositório e ative Settings → Pages → Deploy from a branch → main → /(root).

## Fontes principais
PubChem/NIH — tolueno: https://pubchem.ncbi.nlm.nih.gov/compound/1140
PubChem/NIH — α-terpineno: https://pubchem.ncbi.nlm.nih.gov/compound/7462
WHO/FAO JECFA — α-terpineno: https://apps.who.int/food-additives-contaminants-jecfa-database/Home/Chemical/4633
European Commission/JRC — Tolueno: https://publications.jrc.ec.europa.eu/repository/handle/JRC24380
CDC/NIOSH — Alice Hamilton: https://www.cdc.gov/mmwr/preview/mmwrhtml/mm4822bx.htm
FRASER/U.S. Bureau of Labor Statistics — relatório histórico de 1921: https://fraser.stlouisfed.org/title/industrial-poisoning-making-coal-tar-dyes-dye-intermediates-3892/fulltext
Xhaferaj et al. (2025): https://doi.org/10.58985/jeopc.2025.v03i02.71
